<template>
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><circle cy="12" cx="12" r="12" stroke="currentColor" /></svg>
</template>